# Smart Expense Tracker

A modern and user-friendly expense tracking web application built with Django.

## Features

- User authentication and authorization
- Expense tracking with categories
- Dashboard with expense analytics
- Monthly and yearly expense reports
- Budget management
- Responsive and modern UI

## Setup Instructions

1. Create a virtual environment:
```bash
python -m venv venv
```

2. Activate the virtual environment:
- Windows:
```bash
venv\Scripts\activate
```
- Linux/Mac:
```bash
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run migrations:
```bash
python manage.py migrate
```

5. Create a superuser:
```bash
python manage.py createsuperuser
```

6. Run the development server:
```bash
python manage.py runserver
```

7. Access the application at http://127.0.0.1:8000/

## Project Structure

- `expense_tracker/` - Main project directory
- `expenses/` - Expense tracking app
- `users/` - User management app
- `static/` - Static files (CSS, JS, images)
- `templates/` - HTML templates
- `media/` - User uploaded files

## Technologies Used

- Django 5.0.2
- Bootstrap 5
- Chart.js
- SQLite (development)
- PostgreSQL (production) 